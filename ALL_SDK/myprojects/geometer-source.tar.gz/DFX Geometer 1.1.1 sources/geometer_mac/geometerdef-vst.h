#include "vstplugscarbon.h"

#include "geometerdef.h"

#define TARGET_API_VST

#if TARGET_PLUGIN_USES_DSPCORE
	#define VST_NUM_CHANNELS	2
#else
	#define VST_NUM_CHANNELS	1
#endif

#define TARGET_PLUGIN_USES_VSTGUI	// for now
