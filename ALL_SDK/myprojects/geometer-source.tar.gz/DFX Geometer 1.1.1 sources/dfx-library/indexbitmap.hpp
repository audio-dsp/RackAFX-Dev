
/* This is like CMovieBitmap but allows you to do things directly with
   ints rather than mucking around with floats. Since these kinds of
   things usually aren't actually controls (maybe they're help
   displays), it would be tragic to have to deal with floating point
   crap just because that's the "VST way". 

   Because this control can't change its own value, it doesn't need
   a listener or tag.
*/

#ifndef __dfx_indexbitmap_h
#define __dfx_indexbitmap_h

#include "vstgui.h"

class IndexBitmap : public CControl {
public:
  IndexBitmap (const CRect &size, 
	       long heightone,
	       CBitmap *background, 
	       CPoint &offset);

  virtual ~IndexBitmap () {}

  virtual void draw (CDrawContext*);

  void setindex(int i);
  int getindex() { return idx; }

protected:
  int heightone;
  int idx;
  CPoint offset;
};

#endif
