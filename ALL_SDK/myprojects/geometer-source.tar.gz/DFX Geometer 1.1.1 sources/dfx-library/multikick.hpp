/*------------ by Tom Murphy 7  ][  October 2001 ------------*/

#ifndef __dfx_multikick_h
#define __dfx_multikick_h

#ifndef __vstgui__
#include "vstgui.h"
#endif

/* The Multikick control lets the user select between a number
   of discrete values by clicking on an image. While the mouse
   button is held down, a 'kicked' state will be drawn. Using
   the right mouse button allows for cycling in reverse order.
*/

// the 2 bitmap arrangement styles
enum {
  kStacked,	// all subpixmaps are stacked vertically
  kKickPairs	// kicked/unkicked pairs are side by side
};


/* the multikick constructor takes the following parameters:
   size:
   listener:
   tag:
   numstates:        the number of states that this control should let 
                     the user toggle between.
   heightofoneimage: the height of a single image in pixels
   background:       the bitmap to get the button images from
   offset:

   style:            if kStacked, then the source bitmap holds
                     'kicked' images in-between the 'regular' images,
                     all in a vertical line. if kKickPairs, then the
                     kicked versions are to the right of the regular
                     versions (this way tends to be easier to
                     manipulate in photoshop)

   actualstates:     the number of actual states that the control
                     posesses. If the kick only lets the user set
		     some prefix of the available parameters (perhaps
		     some are not implemented yet), then this lets
		     multikick calculate the right parameter values.
		     If 0, then use the value in 'numstates'.

*/

class MultiKick : public CControl {
public:
  MultiKick (const CRect &size,
             CControlListener *listener,
             long tag,
             int numstates_,
             long heightOfOneImage,  // pixel
             CBitmap *background,
             CPoint &offset,
             long style = kStacked,
	     int actualstates_ = 0);
  virtual ~MultiKick ();

  virtual void draw (CDrawContext*);
  virtual void mouse (CDrawContext *pContext, CPoint &where);

  virtual void setValue(float);
  virtual float getValue();
  virtual bool isDirty();
  virtual void setDirty(const bool val = true);

  virtual bool isMouseDown() { return buttondown; }
  virtual void setMouseDown(bool val=true) { buttondown = val; }
  virtual int  getState() { return actualstate; }
  virtual void setState(int newstate) { actualstate = newstate; }

protected:
  int numstates;
  int numactualstates;
  CPoint offset;
  long heightOfOneImage;
  bool buttondown; /* is a button down? */
  bool obdown;
  int actualstate;
  int oactualstate;
  long style;
};

#endif
