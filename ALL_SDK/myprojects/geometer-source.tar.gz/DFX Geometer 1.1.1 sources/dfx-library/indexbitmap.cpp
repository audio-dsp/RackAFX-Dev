
#include "indexbitmap.hpp"

/* dummy listener that does nothing. */
class IBEmptyListener : public CControlListener {
public:
  virtual void valueChanged (CDrawContext *, CControl *) {}
  IBEmptyListener() {}
};

static IBEmptyListener dummy;

void IndexBitmap::setindex(int i) {
  if (i != idx) setDirty(true);
  idx = i;
}

IndexBitmap::IndexBitmap (const CRect &size, 
                          long one,
                          CBitmap *background, 
                          CPoint &offset) : CControl (size, &dummy,
                                                      tag, background), 
                                            offset (offset),
                                            heightone (one) {
}

void IndexBitmap::draw (CDrawContext *pContext) {
  CPoint where (offset.h, offset.v);

  where.v += idx * heightone;

  if (pBackground) {
    if (bTransparencyEnabled)
      pBackground->drawTransparent (pContext, size, where);
    else
      pBackground->draw (pContext, size, where);
  }

  setDirty (false);
}
