type 'carb' {
};


resource 'carb'(0) {
};
