Soul Force! VST Plugin Source Code
----------------------------------

Included in this zip are the MSVC v6 project files, source code, images and
the blender (http://www.blender.org) file used to render the gui.  You'll also
need the 2.4 VST SDK (get it from the steinberg site: http://www.steinberg.de).
I just used the version of VSTGUI that comes with it.

For the blender file, you'll also need the Anime Ace font from blambot:
http://www.blambot.com/

The OSX XCode files included are courtesy of Bernie Torelli over at Nomad
Factory (http://www.nomadfactory.com), though they do expect a slightly
different folder structure: source code should be in a sources folder, and the
images folder should be renamed resources.

- Niall Moody.
