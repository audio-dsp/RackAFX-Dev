#ifndef __RMSBUDDY_DEF_H
#define __RMSBUDDY_DEF_H

#define RMS_BUDDY_VERSION	0x00010105
#define RMS_BUDDY_PLUGIN_ID	'rbud'
#define RMS_BUDDY_MANUFACTURER_ID	'DFX!'
#define RMS_BUDDY_BUNDLE_ID	"org.destroyfx.RMSBuddy"

#endif
