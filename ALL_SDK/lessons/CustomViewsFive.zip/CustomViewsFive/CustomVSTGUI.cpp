#include "CustomVSTGUI.h"


#ifdef AUPLUGIN
// --- this is called to sync to GUI, from multiple locations (preset changes or our own param sets)
void EventListenerDispatch(void *inRefCon, void *inObject, const AudioUnitEvent *inEvent, UInt64 inHostTime, Float32 inValue)
{
    CCustomVSTGUI* pController = (CCustomVSTGUI*)inObject;
    if(pController)
        pController->setGUIControlsWithActualParameter(inEvent->mArgument.mParameter.mParameterID, inValue);
}
#endif

// --- CTor
CCustomVSTGUI::CCustomVSTGUI(void)
{
	m_pVolLeftLabel = NULL;
	m_pVolLeftKnob = NULL;
	m_pVolLeftEdit = NULL;

	m_pBoostVC = NULL;
	m_pBoostLabel = NULL;
	m_pBoostButton = NULL;
	m_pLeftMeter = NULL;
	m_pChannelOptionMenu = NULL;
}

// --- DTor
CCustomVSTGUI::~CCustomVSTGUI(void)
{
}

int32_t CCustomVSTGUI::getKnobMode() const
{
	/* choices are: kLinearMode;
	kRelativCircularMode;
	kCircularMode; */

	return kLinearMode;
}


// --- open override; create frame and populate with controls
bool CCustomVSTGUI::open(CPlugIn* pPlugIn, VSTGUI_VIEW_INFO* info)
{
	// --- first call the base class to store the API-specific stuff; it will handle most of these chores for you
	bool bSuccess = CVSTGUIController::open(pPlugIn, info);
	if(!bSuccess) return false; // critical failure at base class level, should never happen

#ifdef AUPLUGIN
    if(m_AUInstance)
    {
        // --- create the event listener and tell it the name of our Dispatcher function
        //     EventListenerDispatcher
        verify_noerr(AUEventListenerCreate(EventListenerDispatch, this,
                                           CFRunLoopGetCurrent(), kCFRunLoopDefaultMode, 0.05, 0.05,
                                           &m_AUEventListener));
        // --- start with first control 0
        AudioUnitEvent auEvent;
        
        // --- parameter 0
        AudioUnitParameter parameter = {m_AUInstance, 0, kAudioUnitScope_Global, 0};
        
        // --- set param & add it
        auEvent.mArgument.mParameter = parameter;
       	auEvent.mEventType = kAudioUnitEvent_ParameterValueChange;
        verify_noerr(AUEventListenerAddEventType(m_AUEventListener, this, &auEvent));
        
        // --- notice the way additional params are added using mParameterID
        for(int i=1; i<m_pPlugIn->getControlCount(); i++)
        {
            auEvent.mArgument.mParameter.mParameterID = i;
            verify_noerr(AUEventListenerAddEventType(m_AUEventListener, this, &auEvent));
        }
    }
#endif
    
	// --- set the return variables (you may want to store them too)
	info->size.width = 600;
	info->size.height = 300;

	//-- create the frame rect: it dictates the size in pixels
	CRect frameSize(0, 0, info->size.width, info->size.height);

	// --- construct the frame
	frame = new CFrame(frameSize, this);

	// --- open it
#if defined _WINDOWS || defined WINDOWS || defined _WINDLL
	frame->open(info->window, kHWND);		// for WinOS, window = HWND
#else
    frame->open(info->window, (PlatformType)info->vstPlatformType);	// for MacOS, window = NSView* or HIView (VST2 wrappper only)
#endif

	// --- set the frame background color and/or image
	//
	// COLORS: use either built-in colors, or construct your own from r,g,b,a
	/* --- Built In Constants:
	const CColor kTransparentCColor	= CColor (255, 255, 255,   0);
	const CColor kBlackCColor		= CColor (  0,   0,   0, 255);
	const CColor kWhiteCColor		= CColor (255, 255, 255, 255);
	const CColor kGreyCColor		= CColor (127, 127, 127, 255);
	const CColor kRedCColor			= CColor (255,   0,   0, 255);
	const CColor kGreenCColor		= CColor (  0, 255,   0, 255);
	const CColor kBlueCColor		= CColor (  0,   0, 255, 255);
	const CColor kYellowCColor		= CColor (255, 255,   0, 255);
	const CColor kMagentaCColor		= CColor (255,   0, 255, 255);
	const CColor kCyanCColor		= CColor (  0, 255, 255, 255);*/

	// --- example with built-in color
	frame->setBackgroundColor(kWhiteCColor);

	// --- example with r,g,b,a
	//     here it is red with semi-transparency,
	//     you will see the black (not white) background behind it
	frame->setBackgroundColor(CColor(255, 0, 0, 128));

	// --- setting an image
	//     There are normal bitmaps and tiled (9-part tiled) ones, see VSTGUI4 docs for more info
	//
	// --- NOTE: you must have the bitmap in your resources, either as built-in graphics from RackAFX
	//           or that you manually added - see www.willpirkle.com for a video; it's simple to do
	//           http://www.willpirkle.com/support/video-tutorials/#PIGE
	//
	// --- example of normal bitmap; you will see a black bar around the right edge because this bitmap is too small
	//
	/* UNCOMMENT THIS TO SEE THE NORMAL BITMAP, AND COMMENT THE CHUNK BELOW!
	CBitmap* pBitmap = getBitmap("greymetal.png");

	// --- always check pointer!
	if(pBitmap)
	{
		// --- set it
		frame->setBackground(pBitmap);

		// --- and... forget it (VSTGUI uses reference counting)
		pBitmap->forget();
	}*/

	// --- now do a tiled version, all coords = 0 gives ordinary, infinite tiling in each dimension
	//     I recommend not doing exotic tiling because the rendering is very slow
	//
	// --- example of tiled bitmap
	CBitmap* pTiledBitmap = getBitmap("greymetal.png", 0, 0, 0, 0);

	// --- always check pointer!
	if(pTiledBitmap)
	{
		// --- set it
		frame->setBackground(pTiledBitmap);

		// --- forget after adding this pointer to the frame, VSTGUI uses reference counting
		pTiledBitmap->forget();
	}

	// --- now that the frame has a background, continue with controls
	//     I made this a separate function because it is usually very long
	createControls();

	// --- the main control inits
	initControls();

	return bSuccess;
}

// --- idle processing for updating Meters in RAFX, AU, AAX (VST handles this through param changes)
void CCustomVSTGUI::idle()
{
    // --- left meter control Id = 50; getRAFXParameterNormalized() takes the index (tag) so use
    //     helper function to get it
    int nTag = getTagForRAFXControlId(50);
    
	// --- RAFX: get the RAFX parameter to set the meter value
#if !defined AUPLUGIN && !defined AAXPLUGIN && !defined VSTPLUGIN
	m_pLeftMeter->setValueNormalized(getRAFXParameterNormalized(nTag));
    m_pLeftMeter->invalid();
#endif

    // --- AU: get the AU parameter to set the meter value; NOTE: here the AU Actual Parameter is still [0, 1]
#ifdef AUPLUGIN
    m_pLeftMeter->setValueNormalized(getAUParameterActual(nTag));
    m_pLeftMeter->invalid();
#endif
    
	// --- AAX: get the RAFX parameter to set the meter value
#ifdef AAXPLUGIN
	m_pLeftMeter->setValueNormalized(getAAXParameterNormalized(nTag));
    m_pLeftMeter->invalid();
#endif

	// --- VST: not needed; this is passed back as a param update from the 
	//          process function and connected directly to the meter update

	// --- let base class do its thing
	CVSTGUIController::idle();
}

void CCustomVSTGUI::createControls()
{
	if(!frame)
		return;

	if(!m_pPlugIn)
		return frame->onActivate(true);

	// NOTES ON CREATING CONTROLS
	/*
		TAGS:
			A tag is an integer that identifies the variable that the control is connected to
		    You have many options on how to code your tags; in RackAFX I use a control map due
			to the exotic controls like the LCD and Joystick/XYPad.

			However, since each RAFX variable has a unique ID value, you can use that. It is the
			same ID as listed in the comment block above userInterfaceChange()

		CControlListeners
			Almost all controls are derived from CControl; the control listener is the object that will
			get notified when a value changes - that control listener is this object (see declaration).
			Many controls require that you give them the listner in the constructor.

		TEXT FONTS:
		     NOTE: with VSTGUI4, it is up to you to ensure the font is installed on the
		           target computer; is using exotic fonts, I suggest creating a frame backgroud with
		           the text in place -  less issues

				   You can also use built in fonts that are platform independent
					kSystemFont
					kNormalFontVeryBig
					kNormalFontBig
					kNormalFont
					kNormalFontSmall
					kNormalFontSmaller
					kNormalFontVerySmall
					kSymbolFont

		TEXT STYLES:
			Styles are wire-OR-ed using the following UINTS
			kShadowText
			k3DIn
			k3DOut
			kNoTextStyle
			kNoDrawStyle
			kRoundRectStyle


		FONT STYLES:
			Styles are wire-OR-ed using the following UINTS
			kNormalFace
			kBoldFace
			kItalicFace
			kUnderlineFace
			kStrikethroughFace

	    POSITIONING:
			VSTGUI4 objects are positioned with a CRect object that sets the origin (top, left)
			and size (width, height) variables. The coordinates are based on the view they are being inserted
			into.

		Plugin Control Objects
		Your plugin carries around a list of CUICtrl pointers. You can query the plugin for a CUICtrl pointer
		with the control ID value.
	*/

	// --- create controls
	/*
		As an example, I'll do the stock RackAFX knob group which has:
		1 CTextLabel - the control name
		1 CAnimKnob - the knob
		1 CTextEdit - the edit control

		In this case, I am adding the controls directly to the frame so
		the coordinates are relative to it.
	*/

	// --- add the text label at origin(0,5) size(75,15)
	/*
		Constructor:
	    CTextLabel(const CRect& size,
				   UTF8StringPtr txt = 0,
				   CBitmap* background = 0,
				   const int32_t style = 0)

	As an example, I'll create it first, then set the text rather than using text in constructor*/
	CPoint labelOrigin(0,5);
	CPoint labelSize(75,15);
	CRect labelRect(labelOrigin, labelSize); // can also construct with top, left, bottom, right

	m_pVolLeftLabel = new CTextLabel(labelRect);

	// --- set extra attributes; see CTextLabel & CParamDisplay; there are MANY attributes you can set on CParamDisplay
	//     objects!
	if(m_pVolLeftLabel)
	{
		// --- set font color
		m_pVolLeftLabel->setFontColor(kWhiteCColor);

		// --- set background transparent
		m_pVolLeftLabel->setTransparency(true);

		// --- set the text
		m_pVolLeftLabel->setText("Volume (L)");

		// --- OPTIONAL set the font - if you don't set it, you get platform default (Ariel 10)
		//
		// In this example, I will use a default font
		m_pVolLeftLabel->setFont(kNormalFontSmaller);

		// --- OPTIONAL set the style; note use of getStyle() and wire-OR-ing
		// pLabel->setStyle(pLabel->getStyle() | k3DOut);

		// --- do any more customization, then add to frame
		frame->addView(m_pVolLeftLabel);
	}

	// --- add the knob at origin(16, 22) size(42, 42)
	/*
		Preferred Constructor:
		CAnimKnob(const CRect& size,
				  CControlListener* listener,
				  int32_t tag,
				  int32_t subPixmaps,
				  CCoord heightOfOneImage,
				  CBitmap* background,
				  const CPoint& offset = CPoint (0, 0));

		For knobs, there are two key elements here: subPixmaps is the number of frames in the strip animation graphic
		and heightOfOneImage is just that - the height of one frame. The bitmap is the strip animation graphic.

		For the sslblue.png knob, these are: subPixmaps = 80 and heightOfOneImage = 42
	*/

	CPoint knobOrigin(16, 22);
	CPoint knobSize(42, 42);
	CRect knobRect(knobOrigin, knobSize); // can also construct with top, left, bottom, right

	// --- v6.8+ --> the VSTGUI4 Control Tag MUST match the index of the control in our control list
	//               for proper parameter synchronization with the VST, AU, AAX or RAFX Host
	//               
	int nTag = getTagForRAFXControlId(8); // 8 = left Volume ControlId in RackAFX; function returns index of control, sync'd to VST/AU/AAX parameters
	int nPixMaps = 80;
	int nHtOneImage = 42;

	// --- get the bitmap
	CBitmap* pBitmap = getBitmap("sslblue.png");   // <-- example of getting RAFX GUI designer graphics: you have access to them all!
	//CBitmap* pBitmap = getBitmap("knobvst.png"); // <-- example of getting a graphic from the plugin's resource stream (view code for CustomViewsFive.rc)

	// --- if the bitmap does not exist DO NOT CREATE the control!
	if(pBitmap)
	{
		// --- create it; leave offset at (0,0) - it shifts top,left of control if fine adjustment needed
		m_pVolLeftKnob = new CAnimKnob(knobRect, this, nTag, nPixMaps, nHtOneImage, pBitmap);

		// --- add to frame
		frame->addView(m_pVolLeftKnob);

		// --- forget, VSTGUI uses reference counting
		pBitmap->forget();
	}

	// --- add the edit control at origin(15,67) size(45, 15)
	/*
		Preferred Constructor:
		CTextEdit(const CRect& size,
				  CControlListener* listener,
				  int32_t tag,
				  UTF8StringPtr txt = 0,
				  CBitmap* background = 0,
				  const int32_t style = 0);

		The styles are the same as a CTextLabel, which CTextEdit is derived from. There are MANY
		styles that can be set, making the edit control rounded, with or without frame, etc...
		See docs and experiment!
	*/
	CPoint editOrigin(15, 67);
	CPoint editSize(45, 15);
	CRect editRect(editOrigin, editSize); // can also construct with top, left, bottom, right

	// --- create it: use same nTag variable to link knob/edit
	//     NOTE: uses same tag value as knob above
	m_pVolLeftEdit = new CTextEdit(editRect, this, nTag, "0.00"); // "0.00" is initial text

	// --- customize; this will have black background and magenta font color
	if(m_pVolLeftEdit)
	{
		// --- this is an example of using a non built-in font
		//
		// --- first create the font description
		CFontDesc* fontDesc = new CFontDesc("Microsoft Sans Serif", 10);

		if(fontDesc)
		{
			// --- you can change the style - here is bold
			//     be careful here - some styles don't work well in edit control depending on the font size
			//     for example if font size is too big, italic text will move around as it changes
			fontDesc->setStyle(fontDesc->getStyle() | kBoldFace);

			// --- this should be named createPlatformFont - it creates the font on different platforms
			fontDesc->getPlatformFont();

			// --- set the new font
			m_pVolLeftEdit->setFont(fontDesc);
		}

		// --- set back and font colors
		m_pVolLeftEdit->setBackColor(kBlackCColor);
		m_pVolLeftEdit->setFontColor(kMagentaCColor);

		// --- OR you can make the background transparent
		// pEdit->setTransparency(true);

		// --- give it rounded corners with round radius of 5
		//
		//     RoundRect is a style
		m_pVolLeftEdit->setStyle(m_pVolLeftEdit->getStyle() | kRoundRectStyle);

		// --- round rect radius is an attribute
		m_pVolLeftEdit->setRoundRectRadius(5);

		// --- add to the frame
		frame->addView(m_pVolLeftEdit);
	}

	// --- EXAMPLE OF CREATING A VIEW CONTAINER
	/*
		A powerful feature of VSTGUI4 is the ability to create a view container and add views to it.
		You can then move the whole container around or show/hide it and all subviews will also move/show/hide.
		You can have any number of nested containers.

		In this example, we'll create a view container with a switch (COnOffButton) and a LED VU Meter inside it.
	*/

	/*
		Preferred Constructor:
		CViewContainer(const CRect& rect)
	*/
	CPoint vcOrigin(80, 0);
	CPoint vcSize(100, 120);
	CRect vcRect(vcOrigin, vcSize); // can also construct with top, left, bottom, right

	m_pBoostVC = new CViewContainer(vcRect);
	if(m_pBoostVC)
	{
		// --- set background bitmap, color, or use setTransparency for transparent VC
		CBitmap* pBitmap = getBitmap("lightgreymetal.png"); // <-- RAFX GUI Designer stock graphic item

		// --- if the bitmap does not exist DO NOT CREATE the control!
		if(pBitmap)
		{
			// --- this is also how to change a bitmap on the fly
			m_pBoostVC->setBackground(pBitmap);

			// --- always forget
			pBitmap->forget();
		}

		// --- add controls: note that origin() points are relative to VC, not frame
		CPoint labelOrigin(0,5);
		CPoint labelSize(75,15);
		CRect labelRect(labelOrigin, labelSize); // can also construct with top, left, bottom, right

		// --- create label
		m_pBoostLabel = new CTextLabel(labelRect);

		// --- set extra attributes;
		if(m_pBoostLabel)
		{
			// --- set font color
			m_pBoostLabel->setFontColor(kWhiteCColor);

			// --- set background transparent
			m_pBoostLabel->setTransparency(true);

			// --- set the text
			m_pBoostLabel->setText("Boost");

			// --- do any more customization, then add to VC, not the frame
			m_pBoostVC->addView(m_pBoostLabel);
		}

		// --- add the COnOffButton origin(25,30) size(25, 35)
		/*
			Preferred Constructor:
			COnOffButton(const CRect& size,
						 CControlListener* listener = 0,
						 int32_t tag = -1,
						 CBitmap* background = 0,
						 int32_t style = 0);
		*/
		CPoint buttonOrigin(25, 30);
		CPoint buttonSize(25, 35);
		CRect buttonRect(buttonOrigin, buttonSize); // can also construct with top, left, bottom, right
			
		// --- get the proper VSTGUI tag
		int nTag = getTagForRAFXControlId(45); // 45 =  RAFX ControlID for BOOST

		// --- set background bitmap, color, or use setTransparency for transparent VC
		pBitmap = getBitmap("medprophetbutton.png");// <-- RAFX GUI Designer stock graphic item

		// --- if the bitmap does not exist DO NOT CREATE the control!
		if(pBitmap)
		{
			// --- create button
			m_pBoostButton = new COnOffButton(buttonRect, this, nTag, pBitmap);

			if(m_pBoostButton)
			{
				// --- always forget
				pBitmap->forget();

				// --- do any customizations then add to VC
				m_pBoostVC->addView(m_pBoostButton);
			}
		}

		// --- add the COptionMenu origin(25,30) size(25, 35)
		/*
			Preferred Constructor:
			COptionMenu(const CRect& size, 
						IControlListener* listener, 
						int32_t tag, 
						CBitmap* background = 0, 
						CBitmap* bgWhenClick = 0, 
						const int32_t style = 0);

		*/
		CPoint optionMenuOrigin(12, 98);
		CPoint optionMenuSize(75, 15);
		CRect optionMenuRect(optionMenuOrigin, optionMenuSize); // can also construct with top, left, bottom, right
			
		// --- get the proper VSTGUI tag
		nTag = getTagForRAFXControlId(41); // 41 =  RAFX ControlID for Channel selector

		// --- create button
		m_pChannelOptionMenu = new COptionMenu(optionMenuRect, this, nTag);
		
		// --- no bitmap required, but can be used for custom menu
		if(m_pChannelOptionMenu)
		{
			// --- do any customizations then add to VC
			//     let's make the background white and text blue
			m_pChannelOptionMenu->setBackColor(kWhiteCColor);
			m_pChannelOptionMenu->setFontColor(kBlueCColor);

			// --- populate the option menu with strings from the connected CUICtrl object
			//     This is one of the VSTGUI4 controls that requires additional initialization
			//     CSegmentButton is another one
			// --- get the object with Control ID = to the Option Menu (set in CreateControls() above)
			CUICtrl* pUICtrl = m_pPlugIn->getUICtrlByListIndex(m_pChannelOptionMenu->getTag());
			if(pUICtrl)
			{
				// --- clear
				m_pChannelOptionMenu->removeAllEntry();
			    
				// --- check to make sure this is a UINT control (this is an extra step - no way it cou;dn't be...)
				if(pUICtrl->uUserDataType == UINTData)
				{
					// --- iterate through the pUICtrl->cEnumeratedList until there is nothing left
					bool bWorking = true;
					int m = 0;
					while(bWorking)
					{
						// --- chew off the next string
						stringstream enumString;
						getEnumString(pUICtrl->cEnumeratedList, m, enumString);

						// --- if empty, we are done
						if(enumString.str().size() == 0)
							bWorking = false;
						else
						{
							// --- add this string to the menu (you can tweak this if needed with other characters, etc...)
							m_pChannelOptionMenu->addEntry(enumString.str().c_str(), m);
							m++;
						}
					}
			        
					// --- make sure there are entries; if the above failed (it should never), then set it to something to avoid a crash
					int n = m_pChannelOptionMenu->getNbEntries();
					if(n <= 0)
					{
						m_pChannelOptionMenu->addEntry("-n/a-");
						m_pChannelOptionMenu->setMax(0);
						m_pChannelOptionMenu->setValue(0);
					}
					// --- init to current value of our variable will be done below...
				}
			}

			// --- add it
			m_pBoostVC->addView(m_pChannelOptionMenu);
		}

		// --- add the LED VU Meter origin(25,30) size(25, 35)
		/*
			Preferred Constructor:
			CVuMeter(const CRect& size,
					 CBitmap* onBitmap,
					 CBitmap* offBitmap,
					 int32_t nbLed,
					 int32_t style = kVertical);

		    The VU Meter object is one of several VSTGUI4 objects that requires 2 bitmaps (CSlider is another),
			in this case we need one bitmap for the ON state and another for the OFF state. You also need to know
			the number of LEDs in the meter.

			Our built-in LED bitmaps are only for vertical orientation, but it is easy to generate graphics for
			horizontal meters. Note the style constant.

			NOTE: VU meters must be manually updated in the idle() function to animate them!
		*/
		CPoint meterOrigin(70, 10);
		CPoint meterSize(17, 86);
		CRect meterRect(meterOrigin, meterSize); // can also construct with top, left, bottom, right
		
		// --- get the proper VSTGUI tag
		nTag = getTagForRAFXControlId(50); // 50 = Meter 1

		// --- set background bitmap, color, or use setTransparency for transparent VC
		 CBitmap* onBitmap = getBitmap("vuledon.png");// <-- RAFX GUI Designer stock graphic item
		 CBitmap* offBitmap = getBitmap("vuledoff.png");// <-- RAFX GUI Designer stock graphic item

		 if(onBitmap && offBitmap)
		 {
			m_pLeftMeter = new CVuMeter(meterRect, onBitmap, offBitmap, 20, kVertical);
			if(m_pLeftMeter)
			{
				// --- set the tag; note that this is not really needed since
				//     we need to update meters manually in idle(), but if
				//     you have multiple meters, you may want to index them
				//     for your own bookeeping
				m_pLeftMeter->setTag(nTag);

				// --- forget
				onBitmap->forget();
				offBitmap->forget();

				// --- do any customizations then add to VC
				m_pBoostVC->addView(m_pLeftMeter);
			}
		 }

		// --- add VC to the frame
		frame->addView(m_pBoostVC);
	}

	// --- activate
	frame->onActivate(true);
}

// --- now that controls are created, we sync them to the proper parameters
void CCustomVSTGUI::initControls()
{
	if(!frame)
		return;

	// --- Synchronization to plugin parameters, API dependent
	//
    int nParams = m_pPlugIn->getControlCount();
    for(int i=0; i<nParams; i++)
    {
        #ifdef AUPLUGIN
		// --- For AU plugins, we sync to the ACTUAL parameters stored in our Globals
        setGUIControlsWithActualParameter(i, getAUParameterActual(i));
        #endif
        
        #if !defined AUPLUGIN && !defined AAXPLUGIN && !defined VSTPLUGIN
		// --- For RAFX plugins, we sync to the NORMALIZED parameters stored in our Globals
        setGUIControlsWithNormalizedParameter(i, getRAFXParameterNormalized(i));
        #endif
    }

	// --- For VST and AAX plugins there is *nothing to do* -- the params are initialized automatically after the GUI is shown
	//     via the setParameterNormalized( ) function below, this is part of the API for each

	// --- call the repaint() function on frame
	frame->invalid();
}

// --- There are two uses for this function:
//	   (1) externally called to sync our GUI with the VST client GUI (Ableton allows you to see both at once), pControl will be NULL
//     (2) internally called to sync all controls with the same tag to the same value for RAFX only, here pControl will NOT be NULL and can be
//         used to check if the control really needs updating (an infinite loop won't happen, but I like to play it safer here)
void CCustomVSTGUI::setGUIControlsWithNormalizedParameter(int tag, double normalizedValue, VSTGUI::CControl* pControl)
{	
	if(m_pVolLeftKnob && m_pVolLeftKnob != pControl && m_pVolLeftKnob->getTag() ==  tag)
	{
		m_pVolLeftKnob->setValueNormalized(normalizedValue);
		m_pVolLeftKnob->invalid();
	}

	if(m_pChannelOptionMenu && m_pChannelOptionMenu != pControl && m_pChannelOptionMenu->getTag() ==  tag)
	{
		m_pChannelOptionMenu->setValueNormalized(normalizedValue);
		m_pChannelOptionMenu->invalid();
	}

	if(m_pBoostButton && m_pBoostButton != pControl && m_pBoostButton->getTag() ==  tag)
	{
		m_pBoostButton->setValueNormalized(normalizedValue);
		m_pBoostButton->invalid();
	}

	if(m_pVolLeftEdit && m_pVolLeftEdit != pControl && m_pVolLeftEdit->getTag() ==  tag)
	{
		updateTextControl(m_pVolLeftEdit, tag, normalizedValue);
		m_pVolLeftEdit->invalid();
	}

	if(m_pLeftMeter && m_pLeftMeter->getTag() == tag)
	{
		m_pLeftMeter->setValueNormalized(normalizedValue);
		m_pLeftMeter->invalid();
	}
}

// --- main function for handling control changes
void CCustomVSTGUI::valueChanged(VSTGUI::CControl* pControl)
{
	if(!m_pPlugIn) return;

	// --- get the RAFX ID for this control
	int32_t nTag = pControl->getTag();

	// --- get the control for re-broadcast of some types
	CUICtrl* pUICtrl = m_pPlugIn->getUICtrlByListIndex(nTag);
	if(!pUICtrl) return;

	// --- Normalized control value
	float fNormalizedValue = 0.0;

	// --- edit controls are handled differently than all others since they are text based
	//
	// Use dynamic casting to see if this is an edit control
	CTextEdit* control = dynamic_cast<CTextEdit*>(pControl);
	if(control)
		fNormalizedValue = parseAndUpdateTextControl((CTextEdit*)pControl, pUICtrl);
	else
		fNormalizedValue = pControl->getValueNormalized();

	// --- RAFX, VST, AU, AAX done here; NOTE: for VST, AU, AAX this will update all controls with same tag
	//     It is done for RackAFX below, after the checkUpdateGUI() function
	float fWouldBeValue = setPlugInParameterNormalized(nTag, fNormalizedValue, pControl);
    
	// --- check update GUI RAFX, VST, AU, AAX
	checkSendUpdateGUI(nTag, fWouldBeValue, pControl);

	// --- RAFX: broadcast the new value to all controls with same tag
#if !defined AUPLUGIN && !defined AAXPLUGIN && !defined VSTPLUGIN
	if(!m_pVSTParameterConnector)
		setGUIControlsWithNormalizedParameter(nTag, fNormalizedValue, pControl);
#endif

}

// --- new threadsafe way to do sendUpdateGUI()
void CCustomVSTGUI::checkSendUpdateGUI(int tag, float fValue, VSTGUI::CControl* pControl)
{
	if(!m_pPlugIn) return;
	CLinkedList<GUI_PARAMETER> updateGUIParameters;

	// --- ask plugin for updates
	if(m_pPlugIn->checkUpdateGUI(getRAFXControlIdForTag(tag), fValue, updateGUIParameters, false))
	{
		for(int i = 0; i < updateGUIParameters.count(); i++)
		{
			GUI_PARAMETER* pParam = updateGUIParameters.getAt(i);
			if(pParam)
			{
				pParam->bDirty = true;
				
				// --- alter parameter value
				setPlugInParameterNormalized(getTagForRAFXControlId(pParam->uControlId), getNormalizedValue(getTagForRAFXControlId(pParam->uControlId), pParam->fActualValue, true), pControl);

				// --- sync the GUI to match
				setGUIControlsWithActualParameter(getTagForRAFXControlId(pParam->uControlId), pParam->fActualValue);
			}
		}
		
		// --- plugin needs to clean because it allocted from its address space
		m_pPlugIn->clearUpdateGUIParameters(updateGUIParameters);
	}
}

// --- this function handles setting parameters for RAFX, AU, AAX, VST; you do not need to modify or add anything
//     to this function!
float CCustomVSTGUI::setPlugInParameterNormalized(int nTag, float fNormalizedValue, VSTGUI::CControl* pControl)
{
    if(!m_pPlugIn) return fNormalizedValue;
    
    // --- first find the "would be" value for potential use in checkUpdateGUI()
    CUICtrl* pUICtrl = m_pPlugIn->getUICtrlByListIndex(nTag);
    if(!pUICtrl) return fNormalizedValue;
    
    // --- for VST, need to do this before warping values
    if(m_pVSTParameterConnector)
    {
        // --- note we use an unwarped normalized value here; VST will taper for us
        m_pVSTParameterConnector->guiControlValueChanged(nTag, fNormalizedValue);
    }

#ifdef AAXPLUGIN
    // --- threadsafe write
    std::stringstream str;
    str << nTag+1;
    m_pAAXParameters->SetParameterNormalizedValue(str.str().c_str(),fNormalizedValue);
#endif

    // --- deal with log/volt-octave controls
    if(pUICtrl->bLogSlider)
        fNormalizedValue = calcLogPluginValue(fNormalizedValue);
    else if(pUICtrl->bExpSlider)
        fNormalizedValue = calcVoltOctavePluginValue(fNormalizedValue, pUICtrl);
    
    float fWouldBeValue = calcDisplayVariable(pUICtrl->fUserDisplayDataLoLimit, pUICtrl->fUserDisplayDataHiLimit, fNormalizedValue);
    if(pUICtrl->uUserDataType == UINTData)
    {
        fWouldBeValue = ceil(fWouldBeValue - 0.5);
    }
    
    // --- if VST, done
    if(m_pVSTParameterConnector)
        return fWouldBeValue;

	// --- if AAX, done
#ifdef AAXPLUGIN
	return fWouldBeValue;
#endif

    // --- if AU, sync with event listener
#ifdef AUPLUGIN
    // --- threadsafe atomic write
    AudioUnitParameter param = {m_AUInstance, nTag, kAudioUnitScope_Global, 0};
    AUParameterSet(m_AUEventListener, pControl, &param, fWouldBeValue, 0);
    return fWouldBeValue;
#endif
    
    // --- if RAFX, set in parameters to sync with host
#if !defined AUPLUGIN && !defined AAXPLUGIN && !defined VSTPLUGIN
    if(!m_pRAFXGUISynchronizer) return fWouldBeValue;
    
    if(m_pRAFXGUISynchronizer->nNumParams > 0)
    {
        EnterCriticalSection(&m_pRAFXGUISynchronizer->cs);
        m_pRAFXGUISynchronizer->pGUIParameters[pUICtrl->nGUIRow].fNormalizedValue = fNormalizedValue;
        m_pRAFXGUISynchronizer->pGUIParameters[pUICtrl->nGUIRow].bDirty = true;
        LeaveCriticalSection(&m_pRAFXGUISynchronizer->cs);
    }
#endif
    return fWouldBeValue;
}
