#pragma once
#ifndef __CUSTOMVSTGUI_H
#define __CUSTOMVSTGUI_H

#include "VSTGUIController.h"

class CCustomVSTGUI : public CVSTGUIController
{
public:
	CCustomVSTGUI(void);
	~CCustomVSTGUI(void);

	// --- overrides
	virtual bool open(CPlugIn* pPlugIn, VSTGUI_VIEW_INFO* info);

	// --- do idle processing; meters
	virtual void idle();

	// --- pure abstract base class so we **must** override this
	virtual void valueChanged(VSTGUI::CControl* pControl);

	// --- knob mode override
	virtual int32_t getKnobMode() const;

	// --- must override for parameter sync across various APIs
	//     the implementation will depend on your custom GUI code
	//     but there are helper functions below to make this as easy as possible
	virtual void setGUIControlsWithNormalizedParameter(int tag, double normalizedValue, VSTGUI::CControl* pControl = NULL);

	// --- create controls: common to all APIs
	void createControls();

	// --- init controls: varies with API
	void initControls();	

	// --- threadsafe version for GUI updates from plugin
	void checkSendUpdateGUI(int tag, float fValue, VSTGUI::CControl* pControl);

    // --- set RAFX parameter via different APIs
    float setPlugInParameterNormalized(int nTag, float fNormalizedValue, VSTGUI::CControl* pControl);

protected:
	// --- GUI SPECIFIC CONTROLS
	// since this is a simple example, I will declare them individually, but you could also declare as arrays of controls
	CTextLabel*		m_pVolLeftLabel;
	CAnimKnob*		m_pVolLeftKnob;
	CTextEdit*		m_pVolLeftEdit;
	CViewContainer* m_pBoostVC;
	CTextLabel*		m_pBoostLabel;
	COnOffButton*   m_pBoostButton;
	CVuMeter*		m_pLeftMeter;
	COptionMenu*	m_pChannelOptionMenu;
};
#endif


