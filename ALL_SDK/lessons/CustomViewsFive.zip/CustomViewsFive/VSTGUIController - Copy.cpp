#include "VSTGUIController.h"
//extern void* hInstance;   // Sock2VST3 LIB module handle
//extern void* g_hModule;   // DLL module handle

namespace VSTGUI
{
enum {LOG, VOLTOCTAVE, LINEAR};

#ifdef AUPLUGIN
// --- this is called when presets change for us to sync to GUI
void EventListenerDispatch(void *inRefCon, void *inObject, const AudioUnitEvent *inEvent, UInt64 inHostTime, Float32 inValue)
{
    CVSTGUIController* pController = (CVSTGUIController*)inObject;
    if(pController)
        pController->initControls();
}
#endif

CVSTGUIController::CVSTGUIController()
{
	m_pVolLeftLabel = NULL;
	m_pVolLeftKnob = NULL;
	m_pVolLeftEdit = NULL;

	m_pBoostVC = NULL;
	m_pBoostLabel = NULL;
	m_pBoostButton = NULL;
	m_pLeftMeter = NULL;
	m_pParameterConnector = NULL;

	// create a timer used for idle update: will call notify method
	timer = new CVSTGUITimer (dynamic_cast<CBaseObject*>(this));
}

CVSTGUIController::~CVSTGUIController()
{
	// --- stop timer
	if(timer)
		timer->forget();
}

CMessageResult CVSTGUIController::notify(CBaseObject* /*sender*/, const char* message)
{
    if(message == CVSTGUITimer::kMsgTimer)
    {
        if(frame)
            idle();

        return kMessageNotified;
    }
    return kMessageUnknown;
}

int32_t CVSTGUIController::getKnobMode() const
{
	/* choices are: kLinearMode;
				    kRelativCircularMode;
					kCircularMode; */

	return kLinearMode;
}
bool CVSTGUIController::open(void* window, CPlugIn* pPlugIn, int& nWidth, int& nHeight, void* hPlugInInstance)
{
	if(!window) return false;

	m_pPlugIn = pPlugIn;

#if MAC && AUPLUGIN
	m_AUInstance = (AudioUnit)hPlugInInstance; // this is the AU AudioComponentInstance
#else
	m_hPlugInInstance = hPlugInInstance; // this is needed to ensure the resources exist
#endif

	// --- set the return variables (you may want to store them too)
	nWidth = 600;
	nHeight = 300;

	//-- create the frame rect: it dictates the size in pixels
	CRect frameSize(0, 0, nWidth, nHeight);

	// --- construct the frame
	frame = new CFrame(frameSize, this);

	// --- open it
#if defined _WINDOWS || defined WINDOWS || defined _WINDLL
    frame->open(window, kHWND);		// for WinOS, window = HWND
#else
    frame->open(window, kNSView);	// for MacOS, window = NSView*
#endif

	// --- set the frame background color and/or image
	//
	// COLORS: use either built-in colors, or construct your own from r,g,b,a
	/* --- Built In Constants:
	const CColor kTransparentCColor	= CColor (255, 255, 255,   0);
	const CColor kBlackCColor		= CColor (  0,   0,   0, 255);
	const CColor kWhiteCColor		= CColor (255, 255, 255, 255);
	const CColor kGreyCColor		= CColor (127, 127, 127, 255);
	const CColor kRedCColor			= CColor (255,   0,   0, 255);
	const CColor kGreenCColor		= CColor (  0, 255,   0, 255);
	const CColor kBlueCColor		= CColor (  0,   0, 255, 255);
	const CColor kYellowCColor		= CColor (255, 255,   0, 255);
	const CColor kMagentaCColor		= CColor (255,   0, 255, 255);
	const CColor kCyanCColor		= CColor (  0, 255, 255, 255);*/

	// --- example with built-in color
	frame->setBackgroundColor(kWhiteCColor);

	// --- example with r,g,b,a
	//     here it is red with semi-transparency,
	//     you will see the black (not white) background behind it
	frame->setBackgroundColor(CColor(255, 0, 0, 128));

	// --- setting an image
	//     There are normal bitmaps and tiled (9-part tiled) ones, see VSTGUI4 docs for more info
	//
	// --- NOTE: you must have the bitmap in your resources, either as built-in graphics from RackAFX
	//           or that you manually added - see www.willpirkle.com for a video; it's simple to do
	//           http://www.willpirkle.com/support/video-tutorials/#PIGE
	//
	// --- example of normal bitmap; you will see a black bar around the right edge because this bitmap is too small
	//
	/* UNCOMMENT THIS TO SEE THE NORMAL BITMAP, AND COMMENT THE CHUNK BELOW!
	CBitmap* pBitmap = getBitmap("greymetal.png");

	// --- always check pointer!
	if(pBitmap)
	{
		// --- set it
		frame->setBackground(pBitmap);

		// --- and... forget it (VSTGUI uses reference counting)
		pBitmap->forget();
	}*/

	// --- now do a tiled version, all coords = 0 gives ordinary, infinite tiling in each dimension
	//     I recommend not doing exotic tiling because the rendering is very slow
	//
	// --- example of tiled bitmap
	CBitmap* pTiledBitmap = getBitmap("greymetal.png", 0, 0, 0, 0);

	// --- always check pointer!
	if(pTiledBitmap)
	{
		// --- set it
		frame->setBackground(pTiledBitmap);

		// --- forget after adding this pointer to the frame, VSTGUI uses reference counting
		pTiledBitmap->forget();
	}

	// --- now that the frame has a background, continue with controls
	//     I made this a separate function because it is usually very long
	createControls();

	// --- the main control inits
	initControls(true); // true = setup AU Listener (only once)

    // --- set/start the timer
	if(timer)
	{
        timer->setFireTime(METER_UPDATE_INTERVAL_MSEC);
        timer->start();
    }

	return true;
}

void CVSTGUIController::close()
{
	if(!frame) return;

	// --- stop timer
	if(timer)
		timer->stop();

	//-- on close we need to delete the frame object.
	//-- once again we make sure that the member frame variable is set to zero before we delete it
	//-- so that calls to setParameter won't crash.
	CFrame* oldFrame = frame;
	frame = 0;
	oldFrame->forget(); // this will remove/destroy controls
}

void CVSTGUIController::idle()
{
	if(!m_pPlugIn) return;

	// --- do any custom specific stuff here
	//
	// --- VU Meter objects need to have their value set here so they animate properly
	//     Our VU Meter is connected to the RAFX control ID 50
	//
	// --- NOTE: this is a stock VSTGUI meter object; it has no attack/release like the
	//     RAFX meter objects - this is because my RAFX objects are subclassed from the VSTGUI
	//     CVuMeter and contain a built-in envelope detector that post-processes the value.
	CUICtrl* pUICtrl = m_pPlugIn->getUICtrlByControlID(50);
	if(pUICtrl)
	{
		// --- the meter value is in pUICtrl->m_pCurrentMeterValue
		if(m_pLeftMeter)
			m_pLeftMeter->setValue(*pUICtrl->m_pCurrentMeterValue);
	}

	// --- handle sendUpdateGUI() from the plug-in
	//     check the UPDATE_GUI flag
	//if(m_pPlugIn->m_uPlugInEx[UPDATE_GUI] == 1)
	//{
	//	// --- update the controls
	//	initControls();

	//	// --- reset flag
	//	m_pPlugIn->m_uPlugInEx[UPDATE_GUI] = 0;
	//}

	// --- then, update frame - important; this updates edit boxes, sliders, etc...
	if(frame)
		frame->idle();
}

void CVSTGUIController::createControls()
{
	if(!frame)
		return;

	if(!m_pPlugIn)
		return frame->onActivate(true);

	// NOTES ON CREATING CONTROLS
	/*
		TAGS:
			A tag is an integer that identifies the variable that the control is connected to
		    You have many options on how to code your tags; in RackAFX I use a control map due
			to the exotic controls like the LCD and Joystick/XYPad.

			However, since each RAFX variable has a unique ID value, you can use that. It is the
			same ID as listed in the comment block above userInterfaceChange()

		CControlListeners
			Almost all controls are derived from CControl; the control listener is the object that will
			get notified when a value changes - that control listener is this object (see declaration).
			Many controls require that you give them the listner in the constructor.

		TEXT FONTS:
		     NOTE: with VSTGUI4, it is up to you to ensure the font is installed on the
		           target computer; is using exotic fonts, I suggest creating a frame backgroud with
		           the text in place -  less issues

				   You can also use built in fonts that are platform independent
					kSystemFont
					kNormalFontVeryBig
					kNormalFontBig
					kNormalFont
					kNormalFontSmall
					kNormalFontSmaller
					kNormalFontVerySmall
					kSymbolFont

		TEXT STYLES:
			Styles are wire-OR-ed using the following UINTS
			kShadowText
			k3DIn
			k3DOut
			kNoTextStyle
			kNoDrawStyle
			kRoundRectStyle


		FONT STYLES:
			Styles are wire-OR-ed using the following UINTS
			kNormalFace
			kBoldFace
			kItalicFace
			kUnderlineFace
			kStrikethroughFace

	    POSITIONING:
			VSTGUI4 objects are positioned with a CRect object that sets the origin (top, left)
			and size (width, height) variables. The coordinates are based on the view they are being inserted
			into.

		Plugin Control Objects
		Your plugin carries around a list of CUICtrl pointers. You can query the plugin for a CUICtrl pointer
		with the control ID value.
	*/

	// --- create controls
	/*
		As an example, I'll do the stock RackAFX knob group which has:
		1 CTextLabel - the control name
		1 CAnimKnob - the knob
		1 CTextEdit - the edit control

		In this case, I am adding the controls directly to the frame so
		the coordinates are relative to it.
	*/

	// --- add the text label at origin(0,5) size(75,15)
	/*
		Constructor:
	    CTextLabel(const CRect& size,
				   UTF8StringPtr txt = 0,
				   CBitmap* background = 0,
				   const int32_t style = 0)

	As an example, I'll create it first, then set the text rather than using text in constructor*/
	CPoint labelOrigin(0,5);
	CPoint labelSize(75,15);
	CRect labelRect(labelOrigin, labelSize); // can also construct with top, left, bottom, right

	m_pVolLeftLabel = new CTextLabel(labelRect);

	// --- set extra attributes; see CTextLabel & CParamDisplay; there are MANY attributes you can set on CParamDisplay
	//     objects!
	if(m_pVolLeftLabel)
	{
		// --- set font color
		m_pVolLeftLabel->setFontColor(kWhiteCColor);

		// --- set background transparent
		m_pVolLeftLabel->setTransparency(true);

		// --- set the text
		m_pVolLeftLabel->setText("Volume (L)");

		// --- OPTIONAL set the font - if you don't set it, you get platform default (Ariel 10)
		//
		// In this example, I will use a default font
		m_pVolLeftLabel->setFont(kNormalFontSmaller);

		// --- OPTIONAL set the style; note use of getStyle() and wire-OR-ing
		// pLabel->setStyle(pLabel->getStyle() | k3DOut);

		// --- do any more customization, then add to frame
		frame->addView(m_pVolLeftLabel);
	}

	// --- add the knob at origin(16, 22) size(42, 42)
	/*
		Preferred Constructor:
		CAnimKnob(const CRect& size,
				  CControlListener* listener,
				  int32_t tag,
				  int32_t subPixmaps,
				  CCoord heightOfOneImage,
				  CBitmap* background,
				  const CPoint& offset = CPoint (0, 0));

		For knobs, there are two key elements here: subPixmaps is the number of frames in the strip animation graphic
		and heightOfOneImage is just that - the height of one frame. The bitmap is the strip animation graphic.

		For the sslblue.png knob, these are: subPixmaps = 80 and heightOfOneImage = 42
	*/

	CPoint knobOrigin(16, 22);
	CPoint knobSize(42, 42);
	CRect knobRect(knobOrigin, knobSize); // can also construct with top, left, bottom, right
	CUICtrl* pUICtrl = m_pPlugIn->getUICtrlByControlID(8);
	if(!pUICtrl) return; // failure
	int nTag = pUICtrl->nGUIRow; // index of control, sync'd to VST/AU/AAX parameters
	int nPixMaps = 80;
	int nHtOneImage = 42;

	// --- get the bitmap
	CBitmap* pBitmap = getBitmap("sslblue.png");   // <-- example of getting RAFX GUI designer graphics: you have access to them all!
	//CBitmap* pBitmap = getBitmap("knobvst.png"); // <-- example of getting a graphic from the plugin's resource stream (view code for CustomViewsFive.rc)

	// --- if the bitmap does not exist DO NOT CREATE the control!
	if(pBitmap)
	{
		// --- create it; leave offset at (0,0) - it shifts top,left of control if fine adjustment needed
		m_pVolLeftKnob = new CAnimKnob(knobRect, this, nTag, nPixMaps, nHtOneImage, pBitmap);

		// --- add to frame
		frame->addView(m_pVolLeftKnob);

		// --- forget, VSTGUI uses reference counting
		pBitmap->forget();
	}

	// --- add the edit control at origin(15,67) size(45, 15)
	/*
		Preferred Constructor:
		CTextEdit(const CRect& size,
				  CControlListener* listener,
				  int32_t tag,
				  UTF8StringPtr txt = 0,
				  CBitmap* background = 0,
				  const int32_t style = 0);

		The styles are the same as a CTextLabel, which CTextEdit is derived from. There are MANY
		styles that can be set, making the edit control rounded, with or without frame, etc...
		See docs and experiment!
	*/
	CPoint editOrigin(15, 67);
	CPoint editSize(45, 15);
	CRect editRect(editOrigin, editSize); // can also construct with top, left, bottom, right

	// --- create it: use same nTag variable to link knob/edit
	m_pVolLeftEdit = new CTextEdit(editRect, this, nTag, "0.00"); // "0.00" is initial text

	// --- customize; this will have black background and magenta font color
	if(m_pVolLeftEdit)
	{
		// --- this is an example of using a non built-in font
		//
		// --- first create the font description
		CFontDesc* fontDesc = new CFontDesc("Microsoft Sans Serif", 10);

		if(fontDesc)
		{
			// --- you can change the style - here is bold
			//     be careful here - some styles don't work well in edit control depending on the font size
			//     for example if font size is too big, italic text will move around as it changes
			fontDesc->setStyle(fontDesc->getStyle() | kBoldFace);

			// --- this should be named createPlatformFont - it creates the font on different platforms
			fontDesc->getPlatformFont();

			// --- set the new font
			m_pVolLeftEdit->setFont(fontDesc);
		}

		// --- set back and font colors
		m_pVolLeftEdit->setBackColor(kBlackCColor);
		m_pVolLeftEdit->setFontColor(kMagentaCColor);

		// --- OR you can make the background transparent
		// pEdit->setTransparency(true);

		// --- give it rounded corners with round radius of 5
		//
		//     RoundRect is a style
		m_pVolLeftEdit->setStyle(m_pVolLeftEdit->getStyle() | kRoundRectStyle);

		// --- round rect radius is an attribute
		m_pVolLeftEdit->setRoundRectRadius(5);

		// --- add to the frame
		frame->addView(m_pVolLeftEdit);
	}

	// --- EXAMPLE OF CREATING A VIEW CONTAINER
	/*
		A powerful feature of VSTGUI4 is the ability to create a view container and add views to it.
		You can then move the whole container around or show/hide it and all subviews will also move/show/hide.
		You can have any number of nested containers.

		In this example, we'll create a view container with a switch (COnOffButton) and a LED VU Meter inside it.
	*/

	// --- add the edit control at origin(15,67) size(45, 15)
	/*
		Preferred Constructor:
		CViewContainer(const CRect& rect)
	*/
	CPoint vcOrigin(80, 0);
	CPoint vcSize(100, 120);
	CRect vcRect(vcOrigin, vcSize); // can also construct with top, left, bottom, right

	m_pBoostVC = new CViewContainer(vcRect);
	if(m_pBoostVC)
	{
		// --- set background bitmap, color, or use setTransparency for transparent VC
		CBitmap* pBitmap = getBitmap("lightgreymetal.png"); // <-- RAFX GUI Designer stock graphic item

		// --- if the bitmap does not exist DO NOT CREATE the control!
		if(pBitmap)
		{
			// --- this is also how to change a bitmap on the fly
			m_pBoostVC->setBackground(pBitmap);

			// --- always forget
			pBitmap->forget();
		}

		// --- add controls: note that origin() points are relative to VC, not frame
		CPoint labelOrigin(0,5);
		CPoint labelSize(75,15);
		CRect labelRect(labelOrigin, labelSize); // can also construct with top, left, bottom, right

		// --- create label
		m_pBoostLabel = new CTextLabel(labelRect);

		// --- set extra attributes;
		if(m_pBoostLabel)
		{
			// --- set font color
			m_pBoostLabel->setFontColor(kWhiteCColor);

			// --- set background transparent
			m_pBoostLabel->setTransparency(true);

			// --- set the text
			m_pBoostLabel->setText("Boost");

			// --- do any more customization, then add to VC, not the frame
			m_pBoostVC->addView(m_pBoostLabel);
		}

		// --- add the COnOffButton origin(25,30) size(25, 35)
		/*
			Preferred Constructor:
			COnOffButton(const CRect& size,
						 CControlListener* listener = 0,
						 int32_t tag = -1,
						 CBitmap* background = 0,
						 int32_t style = 0);
		*/
		CPoint buttonOrigin(25, 30);
		CPoint buttonSize(25, 35);
		CRect buttonRect(buttonOrigin, buttonSize); // can also construct with top, left, bottom, right
			
		CUICtrl* pUICtrl = m_pPlugIn->getUICtrlByControlID(45);// RAFX ControlID for BOOST
		if(!pUICtrl) return; // failure
		int nTag = pUICtrl->nGUIRow; // index of control, sync'd to VST/AU/AAX parameters

		// --- set background bitmap, color, or use setTransparency for transparent VC
		pBitmap = getBitmap("medprophetbutton.png");// <-- RAFX GUI Designer stock graphic item

		// --- if the bitmap does not exist DO NOT CREATE the control!
		if(pBitmap)
		{
			// --- create button
			m_pBoostButton = new COnOffButton(buttonRect, this, nTag, pBitmap);

			if(m_pBoostButton)
			{
				// --- always forget
				pBitmap->forget();

				// --- do any customizations then add to VC
				m_pBoostVC->addView(m_pBoostButton);
			}
		}

		// --- add the LED VU Meter origin(25,30) size(25, 35)
		/*
			Preferred Constructor:
			CVuMeter(const CRect& size,
					 CBitmap* onBitmap,
					 CBitmap* offBitmap,
					 int32_t nbLed,
					 int32_t style = kVertical);

		    The VU Meter object is one of several VSTGUI4 objects that requires 2 bitmaps (CSlider is another),
			in this case we need one bitmap for the ON state and another for the OFF state. You also need to know
			the number of LEDs in the meter.

			Our built-in LED bitmaps are only for vertical orientation, but it is easy to generate graphics for
			horizontal meters. Note the style constant.

			NOTE: VU meters must be manually updated in the idle() function to animate them!
		*/
		CPoint meterOrigin(70, 10);
		CPoint meterSize(17, 86);
		CRect meterRect(meterOrigin, meterSize); // can also construct with top, left, bottom, right
		
		// --- TODO Need to fix this?
		nTag = 50; // RAFX ControlID for Meter 1, tag must be set manually

		// --- set background bitmap, color, or use setTransparency for transparent VC
		 CBitmap* onBitmap = getBitmap("vuledon.png");// <-- RAFX GUI Designer stock graphic item
		 CBitmap* offBitmap = getBitmap("vuledoff.png");// <-- RAFX GUI Designer stock graphic item

		 if(onBitmap && offBitmap)
		 {
			m_pLeftMeter = new CVuMeter(meterRect, onBitmap, offBitmap, 20, kVertical);
			if(m_pLeftMeter)
			{
				// --- set the tag; note that this is not really needed since
				//     we need to update meters manually in idle(), but if
				//     you have multiple meters, you may want to index them
				//     for your own bookeeping
				m_pLeftMeter->setTag(nTag);

				// --- forget
				onBitmap->forget();
				offBitmap->forget();

				// --- do any customizations then add to VC
				m_pBoostVC->addView(m_pLeftMeter);
			}
		 }

		// --- add VC to the frame
		frame->addView(m_pBoostVC);
	}

	// --- activate
	frame->onActivate(true);
}

void CVSTGUIController::initControls(bool bSetListener)
{
	if(!frame)
		return;

#ifdef AUPLUGIN
	if(m_AUInstance && bSetListener)
    {
        // --- create the event listener and tell it the name of our Dispatcher function
        //     EventListenerDispatcher
		verify_noerr(AUEventListenerCreate(EventListenerDispatch, this,
                                           CFRunLoopGetCurrent(), kCFRunLoopDefaultMode, 0.05, 0.05,
                                           &m_AUEventListener));

        // --- start with first control 0
 		AudioUnitEvent auEvent;

		// --- parameter 0
		AudioUnitParameter parameter = {m_AUInstance, 0, kAudioUnitScope_Global, 0};

		// --- set param & add it
        auEvent.mArgument.mParameter = parameter;
       	auEvent.mEventType = kAudioUnitEvent_ParameterValueChange;
        verify_noerr(AUEventListenerAddEventType(m_AUEventListener, this, &auEvent));

        // --- notice the way additional params are added using mParameterID
        for(int i=1; i<m_pPlugIn->m_UIControlList.count(); i++)
        {
    		auEvent.mArgument.mParameter.mParameterID = i;
            verify_noerr(AUEventListenerAddEventType(m_AUEventListener, this, &auEvent));
        }
	}
#endif

	// --- initialize the location of the controls based on the plugin variables
	//     this is also used for sendUpdateGUI()
	//
	// --- All VSTGUI controls accept a normalized value; use built in helper functions to make that easy

	// --- Volume L control
	//
	// Get the control object with the ID value: Volume (L) = 8
	CUICtrl* pUICtrl = m_pPlugIn->getUICtrlByControlID(8);
	if(pUICtrl)
	{
		// --- set the initial value; use built in helper functions to make this simple
		float fNormalizedValue = getNormalizedValue(pUICtrl);

		// --- set it on controls with this tag/ID value
		m_pVolLeftKnob->setValue(fNormalizedValue);

		// --- edit controls are trickier - need an extra function to make this easier
		setEditControlValue(m_pVolLeftEdit, pUICtrl);
	}

	// --- BOOST control
	pUICtrl = m_pPlugIn->getUICtrlByControlID(45);
	if(pUICtrl)
	{
		// --- set the initial value; use built in helper functions to make this simple
		float fNormalizedValue = getNormalizedValue(pUICtrl);

		// --- set it on controls with this tag/ID value
		m_pBoostButton->setValue(fNormalizedValue);
	}

	// --- call the repaint() function on frame
	frame->invalid();
}

void CVSTGUIController::setParameterNormalized(int tag, float value)
{
	if(!m_pPlugIn) return;
	// m_pPlugIn->setNormalizedParameter(tag, value);
	
	if(m_pVolLeftKnob && m_pVolLeftKnob->getTag() ==  tag)
	{
		m_pVolLeftKnob->setValueNormalized(value);
		m_pVolLeftKnob->invalid();
	}

	if(m_pVolLeftEdit && m_pVolLeftEdit->getTag() ==  tag)
	{
		m_pVolLeftEdit->setValue(value);
		m_pBoostButton->invalid();
	}

	if(m_pBoostButton && m_pBoostButton->getTag() ==  tag)
	{
		m_pBoostButton->setValueNormalized(value);
		m_pBoostButton->invalid();
	}
}

void CVSTGUIController::valueChanged(VSTGUI::CControl* pControl)
{
	if(!m_pPlugIn) return;

	// --- get the RAFX ID for this control
	int32_t nTag = pControl->getTag();

	// --- get the control for re-broadcast of some types
	CUICtrl* pUICtrl = m_pPlugIn->getUICtrlByListIndex(nTag);
	if(!pUICtrl) return;

	// --- Normalized control value
	float fControlValue = 0.0;

	// --- edit controls are handled differently than all others since they are text based
	//
	// Use dynamic casting to see if this is an edit control
	CTextEdit* control = dynamic_cast<CTextEdit*>(pControl);
	if(control)
		fControlValue = updateEditControl(pControl, pUICtrl);
	else
		fControlValue = pControl->getValue();

	// --- this function handles the case of Option Menus, which are a bit different
	//     as they store actual, not normalized, index values
	float fPluginValue = getPluginParameterValue(fControlValue, pControl);

	// --- deal with log/volt-octave controls
	if(pUICtrl->bLogSlider)
		fPluginValue = calcLogPluginValue(fPluginValue); //log10(9.0*fPluginValue + 1.0);
	else if(pUICtrl->bExpSlider)
		fPluginValue = calcVoltOctavePluginValue(fPluginValue, pUICtrl);

	// --- fPluginValue is now final normalized value for plugin
	//
	// --- this helper function also calls userInterfaceChange() on the plugin
	//
	// --- CHANGE THIS to use the plugin version
	setPlugInParameterNormalized(pUICtrl, fPluginValue);

	if(m_pParameterConnector)
		m_pParameterConnector->parameterValueChanged(pControl);

#ifdef AUPLUGIN
	// --- make an AudioUnitParameter set in our AU buddy
	if(pUICtrl)
	{
		AudioUnitParameter param = { m_AU, nTag, kAudioUnitScope_Global, 0 };

		// --- set the AU Parameter; this calls SetParameter() in the au
		AUParameterSet(AUEventListener, this, &param, (Float32)getControlValue(pCtrl), 0);
	}
#endif

	// --- now broadcast control change to all other controls with same tag, but not this control
	//
	//     Note: there are multiple approaches you can take for synchronizing controls; in this
	//           example I am just hardworing the controls that I know share the same tag
	switch(nTag)
	{
		//case 8: // Volume (L)
		case 0: // Volume (L)
		{
			// --- all controls will use setValue()
			if(pControl != m_pVolLeftKnob)
			{
				m_pVolLeftKnob->setValue(fPluginValue);
				m_pVolLeftKnob->invalid();
			}

			// --- EXCEPT for the edit controls which need text handling
			if(pControl != m_pVolLeftEdit)
				setEditControlValue(m_pVolLeftEdit, pUICtrl);

			break;
		}

		case 45: // boost
		{
			// --- nothing to do, there is only one boost

			break;
		}
	}

}

//int32_t CVSTGUIController::controlModifierClicked (VSTGUI::CControl* pControl, VSTGUI::CButtonState button)//;// { return 0; }	///< return 1 if you want the control to not handle it, otherwise 0
//{
//	return 0;
//}
//
//void CVSTGUIController::controlBeginEdit(VSTGUI::CControl* pControl)
//{
//	if(m_pParentListener)
//		m_pParentListener->controlBeginEdit(pControl);
//}
//
//void CVSTGUIController::controlEndEdit(VSTGUI::CControl* pControl)
//{
//	if(m_pParentListener)
//		m_pParentListener->controlEndEdit(pControl);
//}
//
//void CVSTGUIController::controlTagWillChange (VSTGUI::CControl* pControl)//;// {}
//{
//	return;
//}
//
//void CVSTGUIController::controlTagDidChange (VSTGUI::CControl* pControl)//;// {}
//{
//	return;
//}
//
//#if DEBUG
//char CVSTGUIController::controlModifierClicked (VSTGUI::CControl* pControl, long button)//;// { return 0; }
//{
//	return 0;
//}
//#endif

CBitmap* CVSTGUIController::getBitmap(const CResourceDescription& desc, CCoord left, CCoord top, CCoord right, CCoord bottom)
{
	// --- if coords are all >= 0 then this is a nine-part tiled, else normal
	if (left >= 0 && top >= 0 && right >= 0 && bottom >= 0)
		return loadTiledBitmap(desc, left, top, right, bottom);
	else
		return loadBitmap(desc);

	return NULL; // should never happen
}

CNinePartTiledBitmap* CVSTGUIController::loadTiledBitmap(const CResourceDescription& desc, CCoord left, CCoord top, CCoord right, CCoord bottom)
{

#if defined _WINDOWS || defined _WINDLL
	// --- save
	void* pInstance = hInstance;

	HRSRC rsrc = FindResourceA((HMODULE)hInstance, desc.u.name, "PNG");
	if (!rsrc)
		hInstance = g_hModule;

	CNinePartTiledBitmap* pBM = new CNinePartTiledBitmap(desc, (CNinePartTiledDescription(left, top, right, bottom)));

	// --- restore
	hInstance = pInstance;

	return pBM;

#else

	CNinePartTiledBitmap* pBM = new CNinePartTiledBitmap(desc, (CNinePartTiledDescription(left, top, right, bottom)));

	return pBM;

#endif

}

CBitmap* CVSTGUIController::loadBitmap(const CResourceDescription& desc)
{
#if defined _WINDOWS || defined _WINDLL
	// --- save
	void* pInstance = hInstance;

	// --- choose the proper resource stream
	HRSRC rsrc = FindResourceA((HMODULE)hInstance, desc.u.name, "PNG");
	if (!rsrc)
		hInstance = g_hModule;

	CBitmap* pBM = new CBitmap(desc);

	// --- restore
	hInstance = pInstance;

	return pBM;

#else

	CBitmap* pBM = new CBitmap(desc);
	return pBM;

#endif

}

float CVSTGUIController::getNormalizedValue(CUICtrl* pUICtrl)
{
	float fRawValue = 0;
	switch(pUICtrl->uUserDataType)
	{
		case intData:
		{
			fRawValue = calcSliderVariable(pUICtrl->fUserDisplayDataLoLimit, pUICtrl->fUserDisplayDataHiLimit, *(pUICtrl->m_pUserCookedIntData));
			break;
		}

		case floatData:
		{
			fRawValue = calcSliderVariable(pUICtrl->fUserDisplayDataLoLimit, pUICtrl->fUserDisplayDataHiLimit, *(pUICtrl->m_pUserCookedFloatData));
			break;
		}

		case doubleData:
		{
			fRawValue = calcSliderVariable(pUICtrl->fUserDisplayDataLoLimit, pUICtrl->fUserDisplayDataHiLimit, *(pUICtrl->m_pUserCookedDoubleData));
			break;
		}

		case UINTData:
		{
			fRawValue = calcSliderVariable(pUICtrl->fUserDisplayDataLoLimit, pUICtrl->fUserDisplayDataHiLimit, *(pUICtrl->m_pUserCookedUINTData));
			break;
		}

		default:
			break;
	}

	if(pUICtrl->bLogSlider && pUICtrl->uUserDataType != UINTData)
	{
		fRawValue = calcLogParameter(fRawValue);
	}
	else if(pUICtrl->bExpSlider && pUICtrl->uUserDataType != UINTData)
	{
		if(pUICtrl->fUserDisplayDataLoLimit > 0)
		{
			fRawValue = calcVoltOctaveParameter(pUICtrl);
		}
	}
	return fRawValue;
}

}