#ifndef RAFXVIEWSTRUCTS
#define RAFXVIEWSTRUCTS

#include <vector>
#include <map>
#include <string>

using namespace std;

// --- messages
enum {GUI_DID_OPEN,				/* RAFX GUI called after GUI_RAFX_OPEN, NOT called with GUI_USER_CUSTOM_OPEN */
	  GUI_WILL_CLOSE,			/* RAFX GUI called after GUI_RAFX_CLOSE, but before window is destroyed, NOT called with GUI_USER_CUSTOM_CLOSE */
	  GUI_TIMER_PING,			/* timer ping for custom views */
	  GUI_CUSTOMVIEW,			/* query for a custom view */
	  GUI_SUBCONTROLLER,		/* query for a subcontroller (not supported) */
	  GUI_HAS_USER_CUSTOM,		/* CUSTOM GUI - reply in bHasUserCustomView */
	  GUI_USER_CUSTOM_OPEN,		/* CUSTOM GUI - create your custom GUI, you must supply the code */
	  GUI_USER_CUSTOM_CLOSE,	/* CUSTOM GUI - destroy your custom GUI, you must supply the code */
	  GUI_USER_CUSTOM_SIZE};	/* CUSTOM GUI Size - currently not used, return in the info struct instead */

// --- simple stucts
typedef struct
{
    int x;
    int y;
}VSTGUIPOINT;

typedef struct
{
    int width;
    int height;
}VSTGUISIZE;

typedef struct
{
    int left;
    int top;
	int bottom;
	int right;
}VSTGUIRECT;

// --- info/messaging struct for RAFX<-->GUI Communication
typedef struct
{
	unsigned int message; // type of info message

	// --- string pair attributes
	std::map<std::string,std::string>* uiattributes;

	// --- custom view stuff
	string		customViewName;
	int			customViewTag;
	VSTGUIRECT	customViewRect;
	VSTGUIPOINT customViewOffset;
	string		customViewBitmapName;
	string		customViewHandleBitmapName;		// sliders
	string		customViewOffBitmapName;		// LED Meters
	string		customViewOrientation;				// sliders, switches, meters
	
	void*		customViewBackColor;	// CColor cloaked
	void*		customViewFrameColor;	// CColor cloaked
	void*		customViewFontColor;	// CColor cloaked
	int			customViewFrameWidth;
	int			customViewRoundRectRadius;
	bool		customViewStyleNoFrame;
	bool		customViewStyleRoundRect;

	int			customViewHtOneImage;	// CAnimKnob
	int			customViewSubPixmaps;	// CAnimKnob


	// --- subcontroller stuff
	string subControllerName;
	
	// --- pointer to VST3Editor, if you know how to use it!
	void* editor; // editor
	void* window; // HWND for WinOS or NSView* for MacOS
	void* listener; // HWND for WinOS or NSView* for MacOS
	
	// --- instance stuff
	void* hRAFXInstance;
	void* hPlugInInstance;

	// --- for User Custom View
	bool bHasUserCustomView;

	VSTGUISIZE size; // return variable with GUI width/height, or (-1, -1) if GUI not supported
}VSTGUI_VIEW_INFO;

#endif