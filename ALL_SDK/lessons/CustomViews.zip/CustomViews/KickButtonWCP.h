#ifndef __WPKICKBUTTON__
#define __WPKICKBUTTON__
#include "../vstgui4/vstgui/lib/controls/cbuttons.h"

/* ------------------------------------------------------
     CKickButtonWCP
     Custom VSTGUI Object by Will Pirkle
     Created with RackAFX(TM) Plugin Development Software
     www.willpirkle.com
 -------------------------------------------------------*/
namespace VSTGUI {

class CKickButtonWCP : public VSTGUI::CKickButton
{
public:
	CKickButtonWCP(const CRect& size, IControlListener* listener, int32_t tag, CBitmap* background, const CPoint& offset = VSTGUI::CPoint (0, 0));
	virtual CMouseEventResult onMouseDown (CPoint& where, const CButtonState& buttons) VSTGUI_OVERRIDE_VMETHOD;
	virtual CMouseEventResult onMouseUp (CPoint& where, const CButtonState& buttons) VSTGUI_OVERRIDE_VMETHOD;

private:
	float   fEntryState;
};
//class CKickButtonWCP 
//{
//public:
//	CKickButtonWCP();
//};
#endif;

}
