#include "KnobWCP.h"
#include "../vstgui4/vstgui/lib/cbitmap.h"
#include <cmath>

namespace VSTGUI {

CKnobWCP::CKnobWCP (const CRect& size, IControlListener* listener, int32_t tag, int32_t subPixmaps, CCoord heightOfOneImage, CBitmap* background, const CPoint &offset)
: CAnimKnob (size, listener, tag, subPixmaps, heightOfOneImage, background, offset)
{

}

void CKnobWCP::draw (CDrawContext *pContext)
{
	if(getDrawBackground ())
	{
		// --- in order to make a reverse knob, need to alter the value variable
		//     by inverting it
		double tempValue = value; // save it

		// --- invert so that 0->1 and 1->0
		value = -value + 1.0;

		CPoint where(0, 0);
		if(value >= 0.f && heightOfOneImage > 0.)
		{
			CCoord tmp = heightOfOneImage * (getNumSubPixmaps () - 1);
			if (bInverseBitmap)
				where.y = floor ((1. - value) * tmp);
			else
				where.y = floor (value * tmp);
			where.y -= (int32_t)where.y % (int32_t)heightOfOneImage;
		}
		getDrawBackground()->draw(pContext, getViewSize(), where);

		// --- restore old value
		value = tempValue;
	}
	setDirty (false);
}


}