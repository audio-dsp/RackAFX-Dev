#include "KickButtonWCP.h"

/* ------------------------------------------------------
     CKickButtonWCP
     Custom VSTGUI Object by Will Pirkle
     Created with RackAFX(TM) Plugin Development Software
     www.willpirkle.com
 -------------------------------------------------------*/

namespace VSTGUI {

VSTGUI::CKickButtonWCP::CKickButtonWCP(const CRect& size, IControlListener* listener, int32_t tag, CBitmap* background, const VSTGUI::CPoint& offset)
: VSTGUI::CKickButton(size, listener, tag, background, offset)
{
}


//------------------------------------------------------------------------
VSTGUI::CMouseEventResult CKickButtonWCP::onMouseDown (CPoint& where, const CButtonState& buttons)
{
	if (!(buttons & kLButton))
		return kMouseEventNotHandled;

	value = 1.0;
	fEntryState = value;
	beginEdit ();
	
	// -- fixes 3rd message
	//    This will give two click valueChanged() notifications
	//    On for mouseDown, the other for mouseUp
	//
	//	  remove this chunk of code to get Windows button behavior
	//    of only one notification on mouseUp only
	if (value)
		valueChanged ();
	//value = getMin ();
	// valueChanged ();
	if (isDirty ())
		invalid ();
	//endEdit ();
	// ----- END chunk of code

	return onMouseMoved (where, buttons);
}

//------------------------------------------------------------------------
VSTGUI::CMouseEventResult CKickButtonWCP::onMouseUp (CPoint& where, const CButtonState& buttons)
{
	//if (value)
	//	valueChanged ();
	value = getMin ();
	valueChanged ();
	if (isDirty ())
		invalid ();
	// added this
	endEdit ();
	return kMouseEventHandled;
}


}