#ifndef __cknobwcp__
#define __cknobwcp__

#include "../vstgui4/vstgui/lib/controls/cknob.h"

/* ------------------------------------------------------
     CKnobWCP
     Custom VSTGUI Object by Will Pirkle
     Created with RackAFX(TM) Plugin Development Software
     www.willpirkle.com
 -------------------------------------------------------*/

namespace VSTGUI {

class CKnobWCP : public CAnimKnob
{
	CKnobWCP(const CRect& size, IControlListener* listener, int32_t tag, int32_t subPixmaps, CCoord heightOfOneImage, CBitmap* background, const CPoint& offset = CPoint (0, 0));

	// --- one function to override
	virtual void draw (CDrawContext* pContext) VSTGUI_OVERRIDE_VMETHOD;
};

}

#endif