#pragma once
#include "../vstgui4/vstgui/vstgui.h"

namespace VSTGUI {

class CWaveFormView : public CView
{
public:
	CWaveFormView(const CRect& size);

	virtual void draw(CDrawContext *pContext);	///< called if the view should draw itself

	float* m_pCircBuffer;
	int m_nWriteIndex;
	int m_nReadIndex;
	int m_nLength;

	// --- unipolar peak only
	void addWaveDataPoint(float fSample);
	void clearBuffer();
};

}
