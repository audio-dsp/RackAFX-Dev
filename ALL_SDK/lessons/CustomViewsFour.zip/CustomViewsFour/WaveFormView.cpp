#include "WaveFormView.h"

namespace VSTGUI {

CWaveFormView::CWaveFormView(const VSTGUI::CRect& size)
: CView(size)
{
	m_pCircBuffer = NULL;
	m_pCircBuffer = new float[(int)size.getWidth()];
	m_nWriteIndex = 0;
	m_nReadIndex = 0;
	m_nLength = size.getWidth();
	m_nLength -= 1;
	memset(m_pCircBuffer, 0, m_nLength*sizeof(float));
}

void CWaveFormView::addWaveDataPoint(float fSample)
{
	if(!m_pCircBuffer) return;

	m_pCircBuffer[m_nWriteIndex] = fSample;
	m_nWriteIndex++;
	if(m_nWriteIndex > m_nLength - 1)
		m_nWriteIndex = 0;
}
	
void CWaveFormView::clearBuffer()
{
	if(!m_pCircBuffer) return;
	memset(m_pCircBuffer, 0, sizeof(float));
	m_nWriteIndex = 0;
	m_nReadIndex = 0;
}


void CWaveFormView::draw(CDrawContext* pContext)
{
	// --- bitmap, if one
	if(getDrawBackground())
	{
		getDrawBackground()->draw(pContext, size);
	}
	else
	{		
		// --- setup the backround rectangle
		pContext->setLineWidth(1);
		pContext->setFillColor(CColor(200, 200, 200, 255)); // light grey
		pContext->setFrameColor(CColor(0, 0, 0, 255)); // black
		
		// --- draw the rect filled (with grey) and stroked (line around rectangle)
		pContext->drawRect(size, kDrawFilledAndStroked);

		// --- this will be the line color when drawing lines
		//     alpha value is 200, so color is semi-transparent
		pContext->setFrameColor(CColor(0, 0, 255, 200)); 

		if(!m_pCircBuffer) return;
		
		// --- step through buffer
		int index = m_nWriteIndex - 1;
		for(int i=1; i<m_nLength; i++)
		{
			float sample = m_pCircBuffer[index--];
			float normalized = sample*size.getHeight();
			if(normalized > size.getHeight() - 2)
				normalized = size.getHeight();

			// --- halves
			normalized /= 2.0;

			// --- find the three points of interest
			const CPoint p1(size.left + i, size.bottom - size.getHeight()/2.0);
			const CPoint p2(size.left + i, size.bottom - size.getHeight()/2.0 - normalized);
			const CPoint p3(size.left + i, size.bottom - size.getHeight()/2.0 + normalized);

			// --- move and draw lines
			pContext->drawLine(p1, p2);
			pContext->drawLine(p1, p3);

			// --- wrap the index value if needed
			if(index < 0)
				index = m_nLength - 1;
		}
	}
	setDirty (false);
}

}